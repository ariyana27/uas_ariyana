=== FINAL PROJECT SMT ===

KELOMPOK 12 =

Satriyo Nuraji Rasa

Dandung Janitra Nugroho

1. Clone project dari repository
2. aktifkan XAMPP di laptop 
3. Buka browser Chrome lalu masukin Link 
  http://localhost/phpmyadmin
4. Buat Database dengan nama crud_java
5. Import file .sql di dalam folder db ke database crud_java
6. Buka netbeans
7. Open Project
8. Jika ada error, import library di crud_java-master  .jar
9. lalu RUN PROJECK


![hasil1](https://user-images.githubusercontent.com/47838715/185735870-9abe5989-85e3-4965-b003-011f1e66fd42.png)
